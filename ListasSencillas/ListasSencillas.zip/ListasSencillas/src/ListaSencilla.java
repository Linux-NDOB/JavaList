package PACKAGE_NAME;public class ListaSencilla {
}
